# ifndef josephus_h
# define josephus_h

//MANTER COMO ESPECIFICADO
int josephus(int n, int k);

# endif

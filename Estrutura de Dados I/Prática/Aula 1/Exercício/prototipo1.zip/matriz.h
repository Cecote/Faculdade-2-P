
//usar passagem por referencia
void lerOperacao(char *operacao);
//manter como especificado
void lerMatriz(double M[][12]);
//manter como especificado
double somaMatriz(double M[][12]);
//manter como especificado
double media(double resultado);
//manter como especificado
void printResultado(double resultado);
